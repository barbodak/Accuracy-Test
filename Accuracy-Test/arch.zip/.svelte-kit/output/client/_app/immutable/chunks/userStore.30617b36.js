import{w as t}from"./index.0cf15fe1.js";const e=typeof localStorage<"u"?localStorage.getItem("userData"):null,o=t(typeof e=="string"&&e!=="undefined"?JSON.parse(e):{});export{o as u};
