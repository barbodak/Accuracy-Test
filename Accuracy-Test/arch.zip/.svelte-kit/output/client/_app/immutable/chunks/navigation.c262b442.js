import{j as o}from"./singletons.7cc4b85c.js";const e=o("goto");export{e as g};
