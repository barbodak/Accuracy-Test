import { c as create_ssr_component, b as add_attribute, i as is_promise, n as noop } from "../../../chunks/ssr.js";
import "../../../chunks/userStore.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let data = { username: void 0, password: void 0 };
  let login_promise;
  return `<body><div class="h-screen justify-center flex flex-col items-center bg-gray-200"><h1 class="text-4xl" data-svelte-h="svelte-71he9r">login page</h1> <br> <div><form class="space-y-4"><label for="login_filed" class="block" data-svelte-h="svelte-16z3ng4">username</label> <input type="text" name="username" class="border-2 border-black p-1 rounded-md block"${add_attribute("value", data.username, 0)}> <label for="password_filed" class="block" data-svelte-h="svelte-sz5xnb">password</label> <input type="password" name="password" class="border-2 border-black p-1 rounded-md block"${add_attribute("value", data.password, 0)}> ${function(__value) {
    if (is_promise(__value)) {
      __value.then(null, noop);
      return ` <button type="submit" class="bg-blue-500 border-black border-2 p-1 rounded-md block" data-svelte-h="svelte-2qd92b">...wating</button> `;
    }
    return function() {
      return ` <button type="submit" class="bg-yellow-500 border-black border-2 p-1 rounded-md block" data-svelte-h="svelte-gppm87">Login</button> `;
    }();
  }(login_promise)}</form></div></div></body>`;
});
export {
  Page as default
};
