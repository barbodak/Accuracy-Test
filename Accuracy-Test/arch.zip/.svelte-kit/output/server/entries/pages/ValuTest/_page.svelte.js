import { c as create_ssr_component, b as add_attribute, e as escape, d as each, v as validate_component } from "../../../chunks/ssr.js";
const ValCard = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { id } = $$props;
  let name = String.fromCharCode("A".charCodeAt(0) + id);
  if ($$props.id === void 0 && $$bindings.id && id !== void 0)
    $$bindings.id(id);
  return `<div class=""${add_attribute("draggable", true, 0)} role="button" tabindex="0"><button><img src="${"/images/cards/" + escape(name, true) + ".jpg"}"${add_attribute("alt", name, 0)}> ${``}</button></div>`;
});
function shuffle(array) {
  let currentIndex = array.length, randomIndex;
  while (currentIndex > 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;
    [array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]];
  }
  return array;
}
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let answers = Array(20).fill(-1).map((x, i) => -1 * (i + 1));
  let cardWasUsed = Array(20).fill(false);
  let hoveringOver = 90;
  let cardOrder = shuffle(Array(20).fill(0).map((x, i) => i));
  return `<header class="fixed top-0 w-full bg-blue-950 text-white z-5"><nav class="container mx-auto px-6 py-3"><div class="flex justify-between items-center"><div class="text-lg font-semibold" data-svelte-h="svelte-1firgt8">W.I.L. آزمون</div> <div class="space-x-4 lg:order-2"> <button class="px-4 py-2 bg-red-700 hover:bg-red-800 rounded-lg focus:outline-none" data-svelte-h="svelte-1v7cbc6">پایان آزمون</button></div></div></nav></header> <body><div class="flex mt-16">  <div class="w-1/5 h-screen fixed right-0 bg-black overflow-auto z-0">${each(cardOrder, (card) => {
    return `${cardWasUsed[card] === false ? `<div class="mx-5 my-7">${validate_component(ValCard, "ValCard").$$render($$result, { id: card }, {}, {})} </div>` : ``}`;
  })} </div> <div class="w-4/5 h-screen pl-1/5"><br> <img class="pb-5 px-10" src="/images/quiz/importance_label.png" alt="importance_label"> <div class="grid grid-cols-5 grid-rows-1 gap-x-9 px-5">${each(Array(5), (a, index) => {
    return `<div class="border-2 border-solid rounded-md text-center place-items-center border-black bg-black text-white">ستون ${escape(index == 0 ? "اول" : index == 1 ? "دوم" : index == 2 ? "سوم" : index == 3 ? "چهارم" : "پنجم")} </div>`;
  })}</div> <div class="grid grid-cols-5 grid-rows-4 gap-x-9 gap-y-6 h-5/6 p-5">${each(answers, (answer, index) => {
    return `<div${add_attribute(
      "class",
      "border-2 border-solid rounded-md text-center place-items-center " + (hoveringOver === index ? "border-orange-600" : "border-black"),
      0
    )} role="button" tabindex="0">${answers[index] < 0 ? `<div></div>` : `${validate_component(ValCard, "ValCard").$$render($$result, { id: answers[index] }, {}, {})}`} </div>`;
  })}</div></div></div></body> ${``}`;
});
export {
  Page as default
};
