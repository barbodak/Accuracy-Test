import { c as create_ssr_component, v as validate_component, e as escape } from "../../../../chunks/ssr.js";
import { O as Overlay } from "../../../../chunks/Overlay.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(Overlay, "Overlay").$$render($$result, { isTransparent: false, canBeExited: false }, {}, {
    default: () => {
      return `<p class="text-xl mb-4" data-svelte-h="svelte-1xcd5dh">Welcome to the Values Test</p> <p data-svelte-h="svelte-1qpi0zr">VALUTEST is a test that measures your accuracy in answering questions.</p> <p data-svelte-h="svelte-12zhfbp">these arethe rules</p> <p data-svelte-h="svelte-1lziibi">-rule 1</p> <p data-svelte-h="svelte-99mbbr">-rule 2</p> <p data-svelte-h="svelte-17achk0">-rule 3</p> <p>${escape("Good luck :)")}</p> <button class="bg-green-600 hover:bg-green-900 text-white font-bold py-2 px-4 rounded inline-block mt-2" data-svelte-h="svelte-15ex88">شروع</button>`;
    }
  })}`;
});
export {
  Page as default
};
