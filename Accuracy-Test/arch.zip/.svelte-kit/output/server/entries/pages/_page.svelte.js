import { c as create_ssr_component, v as validate_component, e as escape } from "../../chunks/ssr.js";
import { O as Overlay } from "../../chunks/Overlay.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let first_name = "";
  let last_name = "";
  return `${validate_component(Overlay, "Overlay").$$render($$result, { isTransparent: false, canBeExited: false }, {}, {
    default: () => {
      return `<h1 class="text-xl">Welcome, ${escape(first_name)} ${escape(last_name)}</h1> <br> <br> <h1>${`${`<p data-svelte-h="svelte-1d882m4">You do not have permission to take the AcuTest</p>`}`}</h1> <br> <h1>${`${`<p data-svelte-h="svelte-s9ue0j">You do not have permission to take the ValuTest</p>`}`}</h1>    `;
    }
  })}`;
});
export {
  Page as default
};
