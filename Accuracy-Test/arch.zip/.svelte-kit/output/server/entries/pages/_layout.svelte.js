import { c as create_ssr_component, a as subscribe } from "../../chunks/ssr.js";
import axios from "axios";
import { u as userData } from "../../chunks/userStore.js";
const app = "";
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $userData, $$unsubscribe_userData;
  $$unsubscribe_userData = subscribe(userData, (value) => $userData = value);
  axios.defaults.xsrfCookieName = "csrftoken";
  axios.defaults.xsrfHeaderName = "X-CSRFTOKEN";
  axios.interceptors.request.use((config) => {
    const token = $userData?.token;
    if (token) {
      config.headers.Authorization = `Token ${token}`;
    }
    console.log(config.headers.Authorization);
    return config;
  });
  $$unsubscribe_userData();
  return `${slots.default ? slots.default({}) : ``}`;
});
export {
  Layout as default
};
