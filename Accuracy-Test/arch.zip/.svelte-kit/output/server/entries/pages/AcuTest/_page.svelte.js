import { c as create_ssr_component, e as escape, b as add_attribute, d as each, v as validate_component } from "../../../chunks/ssr.js";
const Question = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const options = ["A", "B", "C", "D"];
  let { selected = "0" } = $$props;
  let { number } = $$props;
  if ($$props.selected === void 0 && $$bindings.selected && selected !== void 0)
    $$bindings.selected(selected);
  if ($$props.number === void 0 && $$bindings.number && number !== void 0)
    $$bindings.number(number);
  return `<div class="flex flex-row h-44 w-screen justify-center my-10"> <img src="${"/images/quiz/" + escape(number, true) + ".png"}" class="border-4 border-black m-10 h-44"${add_attribute("alt", "Question Number " + number.toString, 0)}> ${each(options, (option) => {
    return `<button><img src="${"/images/quiz/" + escape(number, true) + escape(option, true) + ".png"}" class="${"my-10 mx-3 border-4 h-44 " + escape(
      selected === option ? "border-blue-500" : "border-greay-600",
      true
    )}"${add_attribute("alt", "Option " + option + " of Questoin " + number.toString, 0)}> </button>`;
  })}</div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let minutes;
  let seconds;
  let answers = Array(42).fill("0");
  setInterval(
    () => {
    },
    1e3
  );
  const formatTime = (time) => time.toString().padStart(2, "0");
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    minutes = 0;
    seconds = 0;
    $$rendered = ` ${$$result.head += `<!-- HEAD_svelte-1xrlxc2_START --><style data-svelte-h="svelte-1np0ijm">body {
			background-color: #f0f4f8;
		}</style><!-- HEAD_svelte-1xrlxc2_END -->`, ""}  <header class="bg-white shadow-md sticky top-0 z-10"><nav class="container mx-auto px-4 sm:px-6 lg:px-8"><div class="flex items-center justify-between h-16"><div class="flex items-center" data-svelte-h="svelte-8rjalb"><span class="text-xl font-bold text-gray-800">Accuracy Test</span></div> <div class="flex items-center space-x-4"> <div class="bg-gray-100 text-gray-800 font-mono text-lg font-semibold px-4 py-2 rounded-md"><span>${escape(formatTime(minutes))}</span>:<span>${escape(formatTime(seconds))}</span></div>  <button class="text-white bg-red-600 hover:bg-red-700 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 transition-colors duration-200" data-svelte-h="svelte-xsc9zp">End Test</button></div></div></nav></header>  <main class="container mx-auto max-w-6xl p-4 sm:p-6 lg:p-8"> <div class="grid grid-cols-1 gap-8">${each(answers, (_, index) => {
      return `${validate_component(Question, "Question").$$render(
        $$result,
        {
          number: index + 1,
          selected: answers[index]
        },
        {
          selected: ($$value) => {
            answers[index] = $$value;
            $$settled = false;
          }
        },
        {}
      )}`;
    })}</div></main>  ${``}`;
  } while (!$$settled);
  return $$rendered;
});
export {
  Page as default
};
