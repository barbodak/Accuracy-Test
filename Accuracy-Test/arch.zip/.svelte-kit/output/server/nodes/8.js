

export const index = 8;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/ValuTest/start/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/8.1bc0313a.js","_app/immutable/chunks/scheduler.bd12791e.js","_app/immutable/chunks/index.be9189c5.js","_app/immutable/chunks/Overlay.d3115d71.js","_app/immutable/chunks/axios.edfcd65b.js","_app/immutable/chunks/constants.5c640802.js"];
export const stylesheets = [];
export const fonts = [];
