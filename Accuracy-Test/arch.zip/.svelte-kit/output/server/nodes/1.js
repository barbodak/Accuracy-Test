

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.8f74e139.js","_app/immutable/chunks/scheduler.bd12791e.js","_app/immutable/chunks/index.be9189c5.js","_app/immutable/chunks/singletons.7cc4b85c.js","_app/immutable/chunks/index.0cf15fe1.js"];
export const stylesheets = [];
export const fonts = [];
