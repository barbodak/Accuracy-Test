

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.fdc2af14.js","_app/immutable/chunks/scheduler.bd12791e.js","_app/immutable/chunks/index.be9189c5.js","_app/immutable/chunks/navigation.c262b442.js","_app/immutable/chunks/singletons.7cc4b85c.js","_app/immutable/chunks/index.0cf15fe1.js","_app/immutable/chunks/Overlay.d3115d71.js","_app/immutable/chunks/axios.edfcd65b.js","_app/immutable/chunks/constants.5c640802.js"];
export const stylesheets = [];
export const fonts = [];
