

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/Login/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.68596ac8.js","_app/immutable/chunks/scheduler.bd12791e.js","_app/immutable/chunks/index.be9189c5.js","_app/immutable/chunks/userStore.30617b36.js","_app/immutable/chunks/index.0cf15fe1.js","_app/immutable/chunks/axios.edfcd65b.js","_app/immutable/chunks/constants.5c640802.js","_app/immutable/chunks/navigation.c262b442.js","_app/immutable/chunks/singletons.7cc4b85c.js"];
export const stylesheets = [];
export const fonts = [];
