

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/TestEnded/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/6.f59a3483.js","_app/immutable/chunks/scheduler.bd12791e.js","_app/immutable/chunks/index.be9189c5.js"];
export const stylesheets = [];
export const fonts = [];
