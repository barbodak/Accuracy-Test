import { w as writable } from "./index.js";
const storedUserData = typeof localStorage !== "undefined" ? localStorage.getItem("userData") : null;
const userData = writable(typeof storedUserData === "string" && storedUserData !== "undefined" ? JSON.parse(storedUserData) : {});
export {
  userData as u
};
