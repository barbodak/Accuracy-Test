import { c as create_ssr_component, b as add_attribute } from "./ssr.js";
const Overlay = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { canBeExited } = $$props;
  let { isTransparent } = $$props;
  if ($$props.canBeExited === void 0 && $$bindings.canBeExited && canBeExited !== void 0)
    $$bindings.canBeExited(canBeExited);
  if ($$props.isTransparent === void 0 && $$bindings.isTransparent && isTransparent !== void 0)
    $$bindings.isTransparent(isTransparent);
  return `<div role="button"${add_attribute("class", "w-screen h-screen fixed top-0 left-0 flex justify-center items-center " + (isTransparent ? "bg-gray-700 bg-opacity-80" : ""), 0)}><div class="relative flex flex-col justify-center items-center max-w-lg">   <div${add_attribute("class", "bg-blue-950 text-white rounded-md flex flex-col justify-center items-center max-w-lg" + (canBeExited ? "" : " px-8 py-5"), 0)}>${slots.default ? slots.default({}) : ``}</div></div></div>`;
});
export {
  Overlay as O
};
