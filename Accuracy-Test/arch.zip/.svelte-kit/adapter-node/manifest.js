export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png","images/cards/A.jpg","images/cards/B.jpg","images/cards/C.jpg","images/cards/D.jpg","images/cards/E.jpg","images/cards/F.jpg","images/cards/G.jpg","images/cards/H.jpg","images/cards/I.jpg","images/cards/J.jpg","images/cards/K.jpg","images/cards/L.jpg","images/cards/M.jpg","images/cards/N.jpg","images/cards/O.jpg","images/cards/P.jpg","images/cards/Q.jpg","images/cards/R.jpg","images/cards/S.jpg","images/cards/T.jpg","images/quiz/1.png","images/quiz/10.png","images/quiz/10A.png","images/quiz/10B.png","images/quiz/10C.png","images/quiz/10D.png","images/quiz/11.png","images/quiz/11A.png","images/quiz/11B.png","images/quiz/11C.png","images/quiz/11D.png","images/quiz/12.png","images/quiz/12A.png","images/quiz/12B.png","images/quiz/12C.png","images/quiz/12D.png","images/quiz/13.png","images/quiz/13A.png","images/quiz/13B.png","images/quiz/13C.png","images/quiz/13D.png","images/quiz/14.png","images/quiz/14A.png","images/quiz/14B.png","images/quiz/14C.png","images/quiz/14D.png","images/quiz/15.png","images/quiz/15A.png","images/quiz/15B.png","images/quiz/15C.png","images/quiz/15D.png","images/quiz/16.png","images/quiz/16A.png","images/quiz/16B.png","images/quiz/16C.png","images/quiz/16D.png","images/quiz/17.png","images/quiz/17A.png","images/quiz/17B.png","images/quiz/17C.png","images/quiz/17D.png","images/quiz/18.png","images/quiz/18A.png","images/quiz/18B.png","images/quiz/18C.png","images/quiz/18D.png","images/quiz/19.png","images/quiz/19A.png","images/quiz/19B.png","images/quiz/19C.png","images/quiz/19D.png","images/quiz/1A.png","images/quiz/1B.png","images/quiz/1C.png","images/quiz/1D.png","images/quiz/2.png","images/quiz/20.png","images/quiz/20A.png","images/quiz/20B.png","images/quiz/20C.png","images/quiz/20D.png","images/quiz/21.png","images/quiz/21A.png","images/quiz/21B.png","images/quiz/21C.png","images/quiz/21D.png","images/quiz/22.png","images/quiz/22A.png","images/quiz/22B.png","images/quiz/22C.png","images/quiz/22D.png","images/quiz/23.png","images/quiz/23A.png","images/quiz/23B.png","images/quiz/23C.png","images/quiz/23D.png","images/quiz/24.png","images/quiz/24A.png","images/quiz/24B.png","images/quiz/24C.png","images/quiz/24D.png","images/quiz/25.png","images/quiz/25A.png","images/quiz/25B.png","images/quiz/25C.png","images/quiz/25D.png","images/quiz/26.png","images/quiz/26A.png","images/quiz/26B.png","images/quiz/26C.png","images/quiz/26D.png","images/quiz/27.png","images/quiz/27A.png","images/quiz/27B.png","images/quiz/27C.png","images/quiz/27D.png","images/quiz/28.png","images/quiz/28A.png","images/quiz/28B.png","images/quiz/28C.png","images/quiz/28D.png","images/quiz/29.png","images/quiz/29A.png","images/quiz/29B.png","images/quiz/29C.png","images/quiz/29D.png","images/quiz/2A.png","images/quiz/2B.png","images/quiz/2C.png","images/quiz/2D.png","images/quiz/3.png","images/quiz/30.png","images/quiz/30A.png","images/quiz/30B.png","images/quiz/30C.png","images/quiz/30D.png","images/quiz/31.png","images/quiz/31A.png","images/quiz/31B.png","images/quiz/31C.png","images/quiz/31D.png","images/quiz/32.png","images/quiz/32A.png","images/quiz/32B.png","images/quiz/32C.png","images/quiz/32D.png","images/quiz/33.png","images/quiz/33A.png","images/quiz/33B.png","images/quiz/33C.png","images/quiz/33D.png","images/quiz/34.png","images/quiz/34A.png","images/quiz/34B.png","images/quiz/34C.png","images/quiz/34D.png","images/quiz/35.png","images/quiz/35A.png","images/quiz/35B.png","images/quiz/35C.png","images/quiz/35D.png","images/quiz/36.png","images/quiz/36A.png","images/quiz/36B.png","images/quiz/36C.png","images/quiz/36D.png","images/quiz/37.png","images/quiz/37A.png","images/quiz/37B.png","images/quiz/37C.png","images/quiz/37D.png","images/quiz/38.png","images/quiz/38A.png","images/quiz/38B.png","images/quiz/38C.png","images/quiz/38D.png","images/quiz/39.png","images/quiz/39A.png","images/quiz/39B.png","images/quiz/39C.png","images/quiz/39D.png","images/quiz/3A.png","images/quiz/3B.png","images/quiz/3C.png","images/quiz/3D.png","images/quiz/4.png","images/quiz/40.png","images/quiz/40A.png","images/quiz/40B.png","images/quiz/40C.png","images/quiz/40D.png","images/quiz/41.png","images/quiz/41A.png","images/quiz/41B.png","images/quiz/41C.png","images/quiz/41D.png","images/quiz/42.png","images/quiz/42A.png","images/quiz/42B.png","images/quiz/42C.png","images/quiz/42D.png","images/quiz/4A.png","images/quiz/4B.png","images/quiz/4C.png","images/quiz/4D.png","images/quiz/5.png","images/quiz/5A.png","images/quiz/5B.png","images/quiz/5C.png","images/quiz/5D.png","images/quiz/6.png","images/quiz/6A.png","images/quiz/6B.png","images/quiz/6C.png","images/quiz/6D.png","images/quiz/7.png","images/quiz/7A.png","images/quiz/7B.png","images/quiz/7C.png","images/quiz/7D.png","images/quiz/8.png","images/quiz/8A.png","images/quiz/8B.png","images/quiz/8C.png","images/quiz/8D.png","images/quiz/9.png","images/quiz/9A.png","images/quiz/9B.png","images/quiz/9C.png","images/quiz/9D.png","images/quiz/importance_label.png"]),
	mimeTypes: {".png":"image/png",".jpg":"image/jpeg"},
	_: {
		client: {"start":"_app/immutable/entry/start.aeca417b.js","app":"_app/immutable/entry/app.d591c69d.js","imports":["_app/immutable/entry/start.aeca417b.js","_app/immutable/chunks/scheduler.bd12791e.js","_app/immutable/chunks/singletons.7cc4b85c.js","_app/immutable/chunks/index.0cf15fe1.js","_app/immutable/entry/app.d591c69d.js","_app/immutable/chunks/scheduler.bd12791e.js","_app/immutable/chunks/index.be9189c5.js"],"stylesheets":[],"fonts":[]},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js')),
			__memo(() => import('./nodes/4.js')),
			__memo(() => import('./nodes/5.js')),
			__memo(() => import('./nodes/6.js')),
			__memo(() => import('./nodes/7.js')),
			__memo(() => import('./nodes/8.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/AcuTest",
				pattern: /^\/AcuTest\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			},
			{
				id: "/AcuTest/start",
				pattern: /^\/AcuTest\/start\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/Login",
				pattern: /^\/Login\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/TestEnded",
				pattern: /^\/TestEnded\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/ValuTest",
				pattern: /^\/ValuTest\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/ValuTest/start",
				pattern: /^\/ValuTest\/start\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 8 },
				endpoint: null
			}
		],
		matchers: async () => {
			
			return {  };
		}
	}
}
})();

export const prerendered = new Set([]);
