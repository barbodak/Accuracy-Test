<div class="flex items-center w-full gap-4 px-2" aria-hidden="true">
  <span class="text-sm font-bold text-slate-600 dark:text-slate-400 whitespace-nowrap">کم اهمیت ترین</span>
  
  <div class="w-full h-1 bg-gradient-to-r from-orange-400 via-yellow-400 to-green-500 rounded-full relative top-px">
    <!-- Left Arrow Head -->
    <div 
      class="absolute left-0 top-1/2 -translate-y-1/2 w-0 h-0 
             border-t-[6px] border-t-transparent
             border-b-[6px] border-b-transparent
             border-r-[10px] border-r-orange-400 -ml-1">
    </div>
    
    <!-- Right Arrow Head -->
    <div 
      class="absolute right-0 top-1/2 -translate-y-1/2 w-0 h-0 
             border-t-[6px] border-t-transparent
             border-b-[6px] border-b-transparent
             border-l-[10px] border-l-green-500 -mr-1">
    </div>
  </div>

  <span class="text-sm font-bold text-slate-800 dark:text-slate-200 whitespace-nowrap">پر اهمیت ترین</span>
</div>


